#!/usr/bin/bash

export LC_COLLAT=LC
shopt -s extglob


regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
num='[0-9]+$'
#------------------------------------------------------------------------------------------------------------------------------
# add: reg.expr 
#-----------------------------------------------READ TABLE NAME OF THE CELL TO BE MODIFIED-------------------------------------
echo "Enter table name you want to modify data into: "

while true
do
	read tableKey
	if test -f ../DBs/$database_name/$tableKey
	then
	
		tableMeta=$(awk -F":" -v TN=$tableKey '{if($1==TN){print $0}}' ../DBs/$database_name/.${database_name}Meta)
		echo $tableMeta
		if test -n $tableMeta
		then
			tbIsEmpty=`cat ../DBs/$database_name/$tableKey`
			echo $tbIsEmpty
		fi
	
		if test -n "$tableMeta" -a -n "$tbIsEmpty"
		then
			break
		elif test -z "$tableMeta"
		then	
			echo "Table name is not found, enter a valid table name: "
			read tableKey
		elif test -z "$tbIsEmpty"
		then
			echo "Table is empty! Enter another table: "
			read tableKey
	
		fi
	else
		echo "table is not found Re-enter a valid table name: "
	fi
done

#------------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------FETCHING META FILE DETAILS-----------------------------------------------------
typeset -i tbColNum
tb_name=$(echo $tableMeta | cut -d: -f1)  #TB NAME
tbColNum=$(echo $tableMeta | cut -d: -f2) #TB NO OF COLS
let pkcount=$tbColNum*3+3;   #echo $pkcount
pk=`echo $tableMeta |cut -d: -f$pkcount`  #TB P.KEY
echo $tbColNum

let nameCounter=3; let typeCounter=4 ;let nullCounter=5
let iter=0

while test $iter -lt $tbColNum 
do
nameCols[$iter]=`echo $tableMeta |cut -d: -f$nameCounter`
typeCols[$iter]=`echo $tableMeta |cut -d: -f$typeCounter`
nullCols[$iter]=`echo $tableMeta |cut -d: -f$nullCounter`

let nameCounter=$nameCounter+3; let typeCounter=$typeCounter+3 ;let nullCounter=$nullCounter+3
let iter=$iter+1
done 
#--------------------------------------------------------------------------------------------------------------------------------

#--------------------------------------------CHECK COL EXISTS & FETCH COLUMN INDEX-----------------------------------------------
echo "Enter the column of the cell to be modified:" 
while true
do
	read colName
	let iter=0

	while test $iter -lt $tbColNum 
	do
		if [ "${nameCols[$iter]}" == $colName ]
		then
			let colIndx=$iter+1 # FETCH COLUMN INDEX IN TABLE
			let isFound=1
			echo "Column is found!"
			break 
		else
			let isFound=0
		fi

		let iter=$iter+1
	done 
	if test $isFound -eq 1
	then
		break
	else
		echo "Column not found! Enter a valid column:"
	fi
done
echo "colindex= $colIndx"
#--------------------------------------------------------------------------------------------------------------------------------


#-----------------------------------------FETCHING PRIMARY KEY COLUMN INDEX-----------------------------------------------------
let iter=0
while test $iter -lt $tbColNum
do
	if [ $pk == "${nameCols[iter]}" ]
	then
		let pkCol=$iter+1
	fi
let iter=$iter+1
done
#--------------------------------------------------------------------------------------------------------------------------------

#-----------------------------------------------------FETCH PK ROW INDEX-------------------------------------------------------
echo "Enter the Primary key of the cell to be modified"
while true
do	
	if test -f ../DBs/$database_name/$tableKey
	then
		read pkval #check if cell exists in table data
		pkRow=$(awk -F":" -v PKC=$pkCol -v PKV=$pkval '{if(PKV==$PKC){print NR}}' ../DBs/$database_name/$tableKey)
		echo "this is PkRow $pkRow"
		if test -n "$pkRow"
		then
			echo "pk found"
			break
		else
			echo "pk is not found, enter a valid pk: "
		fi
	else
		echo "table is not found"
		break
	fi
done
#-------------------------------------------------------------------------------------------------------------------------------


echo "----------------MODIFY A CELL IN $tbKey------------------"

if [ $pkCol == $colIndx ]
then
	echo "YOU ARE MODIFYING IN A PRIMARY KEY CELL"
	PS3="Are you sure you want to modify it? "
	select choice in Yes No
	do

	case $choice in 
	"Yes")	
		echo " TEST Changing PK cases"
		echo "Enter the new value:"
		read modInpt
		if [ "${typeCols[$iter]}" == 'I' ]
			then
				until [[ $modInpt =~ $num ]]
				do
					echo "Enter integer value: "
					read modInpt
				done
			fi


		if test -f ../DBs/$database_name/$tableKey
		then
			touch /tmp/garbage1	
			awk -F":" -v PR=$pkRow -v PC=$pkCol -v MI=$modInpt '{OFS=FS;if(NR==PR){$PC=MI}print $0}' ../DBs/$database_name/$tableKey > /tmp/garbage1
			cat /tmp/garbage1 > ../DBs/$database_name/$tableKey
		else
			echo "$tableKey is not found"
		fi
		break		
		;;
	"No")
		echo "TEST Changing other cols. enter another col"
		exit
		;;
	*)
	echo "Enter a valid choice"
	;;
	esac
	done
else
	echo "YOU ARE MODIFYING A NON-PRIMARY KEY CELL"
	echo "Enter the new value:"
	read modInpt
	
	if test -f ../DBs/$database_name/$tableKey
	then
		touch /tmp/garbage	
		awk -F":" -v PR=$pkRow -v CI=$colIndx -v MI=$modInpt '{OFS=FS;if(NR==PR){$CI=MI}print $0}' ../DBs/$database_name/$tableKey > /tmp/garbage
		cat /tmp/garbage > ../DBs/$database_name/$tableKey
	else
		echo "$tableKey is not found"
	fi
fi
