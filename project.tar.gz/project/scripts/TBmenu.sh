#!/usr/bin/bash

export database_name
echo "             **** THIS IS THE DATA BASE ENGINE ****"
PS3="select a DDL option  "
select choice in "Create Table" "Delete Table" "More" "Back" "Press enter to re-print the menu"
do
case $REPLY in 
1)
./CreateTB.sh
;;
2)
./DeleteTB.sh
;;
3)
./UpdateTB.sh
;;
4)
break
;;
5)
;;
*)
echo "Enter a valind choice"
;;
esac
done

