#!/usr/bin/bash
PS3="Table manipulation: "
export database_name
clear
select choice in "Insert" "Update" "Delete" "Back" "press enter to reprint the menu"
do
	case $REPLY in 
	1)
	./Insert.sh
	;;
	2)
	./Update.sh
	;;
	3)
	./Delete.sh
	;;
	4)
	break
	;;
	5)
	;;
	*)
	echo "Enter a valid choice"
	;;
	esac
done
