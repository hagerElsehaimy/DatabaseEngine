#!/usr/bin/bash
function DeleteDB
{
		typeset exist
		read database_name
 		regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
		if [[ $database_name =~ $regex ]]
		then
			if test -d ../DBs/$database_name
	 		then 
				chmod +w ../DBs/$database_name/.${database_name}Meta
				rm -r ../DBs/$database_name

				exist=1
			else
				exist=0
	 		fi
		else
			exist=0
		fi
return $exist
}


clear
if test -n "$(ls ../DBs)"
then
	ls ../DBs
echo
echo
echo "Enter DB name you wanna delete: "
echo
echo
	DeleteDB
	d=$?
	if test $d -eq 1
	then	
		echo "loading.."
		sleep 2
		clear
		echo "DB deleted succesfully"
		sleep 2
		clear
	elif test $d -eq 0
	then	
		echo "loading.."
		sleep 2
		clear
		echo "DB is not found"
		echo
		echo
		#sleep 2
		#clear
	fi
else
	echo "No databases found to be deleted"
	echo	
	echo
fi

