#!/usr/bin/bash
clear
echo "                       **** THIS IS THE DATA BASE ENGINE ****"
PS3="Press enter to re-print the menu:"

for db in `ls ../DBs`
do
	chmod +w ../DBs/$db
done

select choice in "Create DataBase" "Delete DataBase" "Open DataBase" "Exit"
do
case $REPLY in 
1)
./CreateDB.sh
;;
2)
./DeleteDB.sh
;;
3)
./OpenDB.sh
;;
4)
for db in `ls ../DBs`
do
	chmod -w ../DBs/$db
done
break
;;
*)
echo "Enter a valid choice"
;;
esac
done

