#!/usr/bin/bash
echo "Enter the name of the table you want to delete from: "
read tb_name
#echo "Enter the primary key of data you want to delete: "
#read pk
regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
	if [[ $tb_name =~ $regex ]]
	then
		if test -f ../DBs/$database_name/$tb_name
		then
			more ../DBs/$database_name/$tb_name
			echo "Enter the primary key of data you want to delete: "
			read pk
			if [[ `grep "$pk:" ../DBs/$database_name/$tb_name` ]]
			then
				grep -v "$pk:" ../DBs/$database_name/$tb_name >tmp; mv tmp ../DBs/$database_name/$tb_name
				#rm  ../DBs/$database_name/tmp
				echo "deleted"
			else
				echo "PK not found"
			fi

		else
			echo "table not exists"
		fi
	else
		echo "input is not valid in table naming"
	fi
