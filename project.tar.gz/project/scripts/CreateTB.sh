#!/usr/bin/bash
export LC_COLLAT=LC
shopt -s extglob

function CreateTB {

	typeset -i created
	read tb_name
	echo
	regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
	pk_regex='*":$pk:".*":NNULL".*'
	if [[ $tb_name =~ $regex ]]
	then

		if test -f  ../DBs/$database_name/$tb_name		#checks if the TB directory exists
			then 
			created=0
		else

			created=1	
		fi 
	else
		created=0
	fi
		
	return $created
}

function DefineStructure {

	typeset -i found 	
	typeset -i no_of_col
	typeset -i counter
	typeset data

	CreateTB 
	found=$?


	if test $found -eq 1
	then
		echo "Enter no of coloumns: "
		read no_of_col
		echo
		echo
		counter=$no_of_col
		data=$tb_name:$no_of_col
		case $counter in

		+([2-9])*([0-9])|1+([0-9]))

			while test $counter -gt 0
			do
 				
				echo "Enter col_name: "
				read col_name
				while [[ $col_name == +([0-9]) ]]
				do	
					echo "Enter a valid coloumn name"
					read col_name
					echo
				done
				
				
				while [[ $data =~ .*:${col_name}.* || "$col_name" == @(I|S|NULL|NNULL) ]]
				do
					echo "you cannot enter a coloumn name with a reserved word"
					echo				
					echo "Enter a valid coloumn name: "
					read col_name
				done

				data_type=""
				constraint=""
				
				while [[ "$data_type" != @(I|S) ]]
				do	
					echo
					echo "Enter its data type I for integer and S for string: "
					read data_type
				done
				
				while [[ "$constraint" != @(NULL|NNULL) ]]
				do
					echo
					echo "Determine null constraint using NULL or NNULL keywords "
					read constraint
				done

				for field in $col_name $data_type $constraint
				do
					data=$data":"$field
				done

				counter=$counter-1
			done
			
			echo
			echo "Enter a PK: "
			read pk
			
			until [[ $data =~ .*":$pk:"['I'|'S']":NNULL".* ]]
			do	
				echo
				echo "Enter a valid coloumn:"
				read pk
			#else
				#echo
				#echo "No pk selected"
				#read pk
			done
				

			chmod +w ../DBs/$database_name/.${database_name}Meta
			data=$data":"$pk
			touch ../DBs/$database_name/$tb_name
			echo $data >> ../DBs/$database_name/.${database_name}Meta
			chmod -w ../DBs/$database_name/.${database_name}Meta
			tb=1
			;;
		*)
			echo
			echo "Undifined number of coloumns"
			tb=0
			;;
		esac	
	fi
return $tb
}

echo "Enter table name you wanna create: "

	DefineStructure
	c=$?
	if test $c -eq 1
	then
		echo "TB created succesfully"
		sleep 1
		clear
	
	elif test $c -eq 0
	then
		echo "Cannot create table with this features"

	fi
