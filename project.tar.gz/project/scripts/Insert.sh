#!/usr/bin/bash
export LC_COLLAT=LC
shopt -s extglob

#export db_name 
#--------------fetching table skeleton from meta file------------------

echo "Enter table name you want to insert data into: "
read tableKey

until test -f ../DBs/$database_name/$tableKey 
do
	echo "Enter a valid table name:"
	read tableKey
done
 
tableMeta=$(awk -F":" -v TN=$tableKey '{if($1==TN){print $0}}' ../DBs/$database_name/.${database_name}Meta)
typeset -i tbColNum
tb_name=$(echo $tableMeta | cut -d: -f1)
tbColNum=$(echo $tableMeta | cut -d: -f2)
let nameCounter=3
let typeCounter=4
let nullCounter=5
let iter=0
let pkcount=$tbColNum*3+3


while test $iter -lt $tbColNum 
do
nameCols[$iter]=`echo $tableMeta |cut -d: -f$nameCounter`
typeCols[$iter]=`echo $tableMeta |cut -d: -f$typeCounter`
nullCols[$iter]=`echo $tableMeta |cut -d: -f$nullCounter`
let nameCounter=$nameCounter+3
let typeCounter=$typeCounter+3
let nullCounter=$nullCounter+3
let iter=$iter+1
done 

let nullCounter=$nullCounter
pk=`echo $tableMeta |cut -d: -f$pkcount`



# ---------------------interacting with user-----------------------------

let nameCounter=3
let typeCounter=4
let nullCounter=5
let iter=0
let pkcount=$tbColNum*3+3
regex='^[a-z|A-Z]+[0-9|a-z|A-Z|\d]*$'
num='[0-9]+$'

echo "                ------INSERT INTO TABLE $tb_name------"

while test $iter -lt $tbColNum 
do	typeset -i it
	it=$iter+1
	echo "VALUE OF ${nameCols[$iter]}: "
	
	if test $iter -eq 0  #if I'm inserting the first col
	then
		
		if [ "${nameCols[$iter]}" == "$pk" ] 
		then

			#until test -n "$colVal" #makes sure no null val
			#do
				read colVal	
			#done
			
			if [ "${typeCols[$iter]}" == 'I' ]
			then
				until [[ $colVal =~ $num ]]
				do
					echo "Enter integer value: "
					read colVal
				done
			else
				until [[ $colVal =~ $regex ]]
				do
					echo "Enter string string string value: "
					read colVal
				done
			fi
		
			isUnique=$(awk -F":" -v CV=$colVal -v i=$it  '{if($i==CV){print $0}}' ../DBs/$database_name/$tb_name)
			
			until test -z "$isUnique"
			do	isUnique=""
				echo "PK ${nameCols[$iter]} value already exists!"
				read colVal
				isUnique=$(awk -F":" -v CV=$colVal -v i=$it  '{if($i==CV){print $0}}' ../DBs/$database_name/$tb_name)
			done
				#echo $isUnique
		else # if the input col is not the primary key
			if [ "${nullCols[$iter]}" == "NNULL" ] 
			then
				if [ "${typeCols[$iter]}" == "I" ]
				then
					until [[ $colVal =~ $num ]]
					do
						echo "Enter value: "
						read colVal
					done
				else
					until [[ $colVal =~ $regex ]]
					do
						echo "Enter value: "
						read colVal
					done
				fi
			#will reads until a non null val ientered				
				#until test -n "$colVal"
				#do	
				#	read colVal
				#	echo "colvall NNull read"
				#done

			elif [ "${nullCols[$iter]}" == "NULL" ] #IF IT ACCEPTS NULL
			then	
				if [ "${typeCols[$iter]}" == "I" ]
				then

					if [[ ! $colVal =~ $num || ! $colVal = '' ]]
					then
						echo "Enter int value: "
						read colVal
				elif [[ ! $colVal =~ $regex || ! $colVal = '' ]]
				then	
						echo "Enter sst value: "
						read colVal
					fi
				fi
			fi
		fi
		myRecord=$myRecord$colVal
		colVal=""
	else #if I'm inserting any col other than the first (just to put : before col in myRecord
			read colVal
		if [ "${nameCols[$iter]}" == "$pk" ] #add the string or integer reg.express.
		then
			if [ "${typeCols[$iter]}" == "I" ]
			then
				until [[ $colVal =~ $num ]]
				do
					echo "Enter int value: "
					read colVal
				done
			else
				until [[ $colVal =~ $regex ]]
				do
					echo "Enter string value: "
					read colVal
				done
			fi
		
			isUnique=$(awk -F":" -v CV=$colVal -v i=$it  '{if($i==CV){print $0}}' ../DBs/$database_name/$tb_name)
			echo $isUnique
			until test -z "$isUnique"
			do	isUnique=""
				echo "PK ${nameCols[$iter]} value already exists!"
				read colVal
				isUnique=$(awk -F":" -v CV=$colVal -v i=$it  '{if($i==CV){print $0}}' ../DBs/$database_name/$tb_name)
			done
				echo $isUnique

		else # if the input col is not the primary key
			if [ "${nullCols[$iter]}" == "NNULL" ] 
			then	
				if [ "${typeCols[$iter]}" == "I" ]
				then
					until [[ $colVal =~ $num ]]
					do
						echo "Enter value: "
						read colVal
					done
				else
					until [[ $colVal =~ $regex ]]
					do
						echo "Enter value: "
						read colVal
					done
				fi	
			#will reads until a non null val is entered				
				#until test -n "$colVal" 
				#do	
				#	read colVal
				#done
			elif [ "${nullCols[$iter]}" == "NULL" ] #IF IT ACCEPTS NULL
			then
				if [ "${typeCols[$iter]}" == "I" ]
				then
					if [[ $colVal =~ $num ]]
					then
						echo "Enter value: "
						read colVal
				else [[ $colVal =~ $regex ]]
						echo "Enter value: "
						read colVal
					fi
				fi
			fi
		fi
		colVal=":$colVal"
		echo colVal #test
		myRecord=$myRecord$colVal
		colVal=""
	fi

	echo $myRecord

	let nameCounter=$nameCounter+3
	let typeCounter=$typeCounter+3
	let nullCounter=$nullCounter+3
	let iter=$iter+1
done

if test -f ../DBs/$database_name/$tb_name
then
	echo "$myRecord" >> ../DBs/$database_name/$tb_name
fi
