#!/usr/bin/bash

function CreateDB
{               
		typeset -i exist
		read database_name
		regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
			if [[ $database_name =~ $regex ]]
			then

				if test -d ../DBs/$database_name
		 		then 
					exist=0
				else
					mkdir ../DBs/$database_name
					touch ../DBs/$database_name/.${database_name}Meta
					chmod -w ../DBs/$database_name/.${database_name}Meta
					
					exist=1
		 		fi
			else
				exist=0
			fi

return $exist
}
	clear

	echo "Enter DB name you wanna create: "
	CreateDB
	c=$?	
	if [[ $c -eq 1 ]]
	then
		echo "loading.."
		sleep 2
		clear
		echo "DB created succesfully"
		sleep 2
		clear
		export database_name
		 ./TBmenu.sh
	
	elif [[ $c -eq 0 ]]
	then
		clear
		echo "loading.."
		sleep 2
		clear
		echo "Invalid DB creation"
		echo
		echo

	fi
