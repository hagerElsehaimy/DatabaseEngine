#!/usr/bin/bash

clear
export database_name

regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'

if test -n "$(ls ../DBs)"
then
	ls ../DBs
	echo
	echo
	echo "Enter DB name you want to open"
	read database_name
	echo "loading.."
	sleep 2
	clear
else
	echo "No databases found"
fi

if [[ $database_name =~ $regex ]]
then

	if test -d ../DBs/$database_name
	then
		
		if test -z "$(ls ../DBs/$database_name)"
		then

			echo "No tables created yet!"
			sleep 2
			clear
			./TBmenu.sh
		else
			echo "$database_name has these tables: "
			ls ../DBs/$database_name
			./TBmenu.sh
			#echo "enter tb name: "
			#read tb_name
			if [[ $tb_name =~ $regex ]]
			then
				if test -f ../DBs/$database_name/$tb_name
				then

					./TBmenu.sh
				else
					echo "$tb_name is not exist"
					./TBmenu.sh
				fi
			else
				echo "Invalid table name"
				sleep 2
				clear
			fi
		fi
	else
		echo "database not found "
		echo
		echo
	fi

else
	echo "Invalid DB name"
	sleep 2
	clear
fi

