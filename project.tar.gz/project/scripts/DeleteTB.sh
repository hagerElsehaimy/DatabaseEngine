#!/usr/bin/bash
echo "Enter the name of the table to be deleted"
read tb_name
regex='^[a-z|A-Z][0-9|a-z|A-Z|_|\d]*$'
	if [[ $tb_name =~ $regex ]]
	then
		if test -f ../DBs/$database_name/$tb_name
		then
			chmod +w ../DBs/$database_name/.${database_name}Meta
			grep -v "$tb_name:" ../DBs/$database_name/.${database_name}Meta >tmp; mv tmp ../DBs/$database_name/.${database_name}Meta
			rm  ../DBs/$database_name/$tb_name
			chmod -w ../DBs/$database_name/.${database_name}Meta
			echo "$tb_name deleted successfully"

		else
			echo "table not exists"
		fi
	else
		echo "not found"
	fi
